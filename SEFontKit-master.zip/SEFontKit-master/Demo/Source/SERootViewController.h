//
//  SERootViewController.h
//  SEFontKit
//
//  Created by Sergio Estevao on 27/01/2013.
//  Copyright (c) 2013 Sergio Estevao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SERootViewController : UITabBarController

@end
