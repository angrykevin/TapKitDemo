//
//  NSString_SEExtension.h
//  Demo
//
//  Created by Sergio Estevao on 21/10/2012.
//  Copyright (c) 2012 TigerSpike. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString ()

@end
